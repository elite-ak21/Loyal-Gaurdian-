gdjs.LobbyCode = {};
gdjs.LobbyCode.localVariables = [];
gdjs.LobbyCode.GDBlackDecoratedButtonObjects1= [];
gdjs.LobbyCode.GDBlackDecoratedButtonObjects2= [];


gdjs.LobbyCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlackDecoratedButton"), gdjs.LobbyCode.GDBlackDecoratedButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LobbyCode.GDBlackDecoratedButtonObjects1.length;i<l;++i) {
    if ( gdjs.LobbyCode.GDBlackDecoratedButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.LobbyCode.GDBlackDecoratedButtonObjects1[k] = gdjs.LobbyCode.GDBlackDecoratedButtonObjects1[i];
        ++k;
    }
}
gdjs.LobbyCode.GDBlackDecoratedButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.multiplayer.hasLobbyGameJustStarted());
}
if (isConditionTrue_0) {
{gdjs.multiplayer.openLobbiesWindow(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.multiplayer.hasLobbyGameJustStarted();
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}}

}


};

gdjs.LobbyCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LobbyCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.LobbyCode.GDBlackDecoratedButtonObjects2.length = 0;

gdjs.LobbyCode.eventsList0(runtimeScene);
gdjs.LobbyCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.LobbyCode.GDBlackDecoratedButtonObjects2.length = 0;


return;

}

gdjs['LobbyCode'] = gdjs.LobbyCode;
